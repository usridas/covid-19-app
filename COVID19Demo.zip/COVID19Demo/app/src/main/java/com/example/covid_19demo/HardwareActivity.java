package com.example.covid_19demo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

import java.io.File;

public class HardwareActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hardware);

        Button buttonE = (Button) findViewById(R.id.button5);
        buttonE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int count = 0;
                final CheckBox checkBox1 = (CheckBox) findViewById(R.id.checkBox1);
                if (checkBox1.isChecked()) {
                    count = count + 1;
                    checkBox1.setChecked(false);
                }
                final CheckBox checkBox2 = (CheckBox) findViewById(R.id.checkBox2);
                if (checkBox2.isChecked()) {
                    count = count + 1;
                    checkBox2.setChecked(false);
                }
                final CheckBox checkBox3 = (CheckBox) findViewById(R.id.checkBox3);
                if (checkBox3.isChecked()) {
                    count = count + 1;
                    checkBox3.setChecked(false);
                }
                final CheckBox checkBox4 = (CheckBox) findViewById(R.id.checkBox4);
                if (checkBox4.isChecked()) {
                    count = count + 1;
                    checkBox4.setChecked(false);
                }
                final CheckBox checkBox5 = (CheckBox) findViewById(R.id.checkBox5);
                if (checkBox5.isChecked()) {
                    count = count + 1;
                    checkBox5.setChecked(false);
                }
                final CheckBox checkBox6 = (CheckBox) findViewById(R.id.checkBox6);
                if (checkBox6.isChecked()) {
                    count = count + 1;
                    checkBox6.setChecked(false);
                }
                final CheckBox checkBox7 = (CheckBox) findViewById(R.id.checkBox7);
                if (checkBox7.isChecked()) {
                    count = count + 1;
                    checkBox7.setChecked(false);
                }
                final CheckBox checkBox8 = (CheckBox) findViewById(R.id.checkBox8);
                if (checkBox8.isChecked()) {
                    count = count + 1;
                    checkBox8.setChecked(false);
                }
                if (count <= 2)
                {
                    goToWarning();
                }
                if (count > 2)
                {
                    goToEmergency1Activity();
                }
                count = 0;
            }
        });
    }
    private void goToWarning() {
        Intent intent = new Intent(this, WarningActivity.class);
        startActivity(intent);
    }
    private void goToEmergency1Activity() {
        Intent intent = new Intent(this, Emergency1Activity.class);
        startActivity(intent);
    }
}
