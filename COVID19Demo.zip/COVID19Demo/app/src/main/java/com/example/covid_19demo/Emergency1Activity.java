package com.example.covid_19demo;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.net.Uri;
import android.widget.Toast;

public class Emergency1Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emergency1);

        Button buttonC = (Button) findViewById(R.id.button3);
        buttonC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { goToEmergency2Activity();
            }
        });
        Button buttonD = (Button) findViewById(R.id.button4);
        buttonD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { goToEmergency3Activity();
            }
        });
    }
    private void goToEmergency2Activity() {
        Toast.makeText(this, "People in your community have been alerted. Please call 911.",
                Toast.LENGTH_LONG).show();
        Uri number = Uri.parse("tel:911");
        Intent callIntent = new Intent(Intent.ACTION_DIAL, number);
        startActivity(callIntent);
    }
    private void goToEmergency3Activity() {
        Toast.makeText(this, "No one has been alerted. Please call 911.",
                Toast.LENGTH_LONG).show();
        Uri number = Uri.parse("tel:911");
        Intent callIntent = new Intent(Intent.ACTION_DIAL, number);
        startActivity(callIntent);
    }
}
